/**	Options for the autoHeight add-on. */
interface mmOptionsAutoheight {

	/** What type of height to use. */
	height ?: 'default' | 'auto' | 'highest'
}
