export default {
	'Menu': 'Меню'
};