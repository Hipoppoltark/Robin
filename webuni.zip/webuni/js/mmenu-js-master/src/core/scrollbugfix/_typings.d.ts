//	Add-on options interface.
interface mmOptionsScrollbugfix {
	fix ?: boolean
}
