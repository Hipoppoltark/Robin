/**	Options for the lazySubmenus add-on. */
interface mmOptionsLazysubmenus {

	/** Whether or not to lazy load submenus. */
	load ?: boolean
}
